
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Cyber Station
 */
public class VerialbleClass {
    
    public   String  userName2  = "Admin";    
    ArrayList<String> userName = new ArrayList();
    public   String  userName3 = "";    
    public   String  userName24 = "";    
   // public static  String  userName3  = "";    
}
